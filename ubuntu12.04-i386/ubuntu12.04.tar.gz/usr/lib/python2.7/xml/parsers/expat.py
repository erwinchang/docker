"""Interface to the Expat non-validating XML parser."""
__version__ = '$Revision: 17640 $'

from pyexpat import *
