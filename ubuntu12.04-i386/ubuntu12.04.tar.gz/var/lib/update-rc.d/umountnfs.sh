update-rc.d umountnfs.sh start 31 0 6 .
